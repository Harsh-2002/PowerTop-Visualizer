import React, { useState } from 'react';
import { Upload, Battery, Cpu, BarChart3, Clock, AlertCircle } from 'lucide-react';
import FileUpload from './components/FileUpload';
import Dashboard from './components/Dashboard';
import { PowerTopData, parsePowerTopHtml } from './utils/parser';

function App() {
  const [powerTopData, setPowerTopData] = useState<PowerTopData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = async (content: string) => {
    try {
      const data = parsePowerTopHtml(content);
      setPowerTopData(data);
      setError(null);
    } catch (err) {
      setError('Failed to parse PowerTop report. Please ensure it\'s a valid HTML export.');
      setPowerTopData(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <nav className="border-b border-gray-700 bg-gray-900/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center space-x-3">
            <Battery className="w-8 h-8 text-green-400" />
            <h1 className="text-2xl font-bold">PowerTop Visualizer</h1>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!powerTopData ? (
          <div className="max-w-2xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">Analyze Your PowerTop Report</h2>
              <p className="text-gray-400">
                Upload your PowerTop HTML report to visualize power consumption and system statistics
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <FeatureCard
                icon={<Cpu className="w-6 h-6 text-blue-400" />}
                title="CPU Usage Analysis"
                description="Detailed breakdown of processor utilization and power states"
              />
              <FeatureCard
                icon={<BarChart3 className="w-6 h-6 text-purple-400" />}
                title="Power Consumption"
                description="Visualize power usage patterns and identify power-hungry processes"
              />
              <FeatureCard
                icon={<Clock className="w-6 h-6 text-green-400" />}
                title="Runtime Statistics"
                description="Track process runtime and wakeup events"
              />
              <FeatureCard
                icon={<Battery className="w-6 h-6 text-yellow-400" />}
                title="Battery Metrics"
                description="Monitor battery health and discharge rates"
              />
            </div>

            <FileUpload onUpload={handleFileUpload} />
            
            {error && (
              <div className="mt-4 p-4 bg-red-900/50 border border-red-700 rounded-lg flex items-center space-x-2">
                <AlertCircle className="w-5 h-5 text-red-400" />
                <p className="text-red-200">{error}</p>
              </div>
            )}
          </div>
        ) : (
          <Dashboard data={powerTopData} onReset={() => setPowerTopData(null)} />
        )}
      </main>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6 hover:bg-gray-800/70 transition-colors">
      <div className="flex items-center space-x-3 mb-3">
        {icon}
        <h3 className="font-semibold text-lg">{title}</h3>
      </div>
      <p className="text-gray-400">{description}</p>
    </div>
  );
}

export default App;