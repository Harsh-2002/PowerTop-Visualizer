export interface PowerTopData {
  timestamp: string;
  systemInfo: {
    version: string;
    kernel: string;
    system: string;
    cpu: string;
    os: string;
  };
  summary: {
    powerConsumption: number;
    cpuUsage: number;
    runtime: number;
    wakeups: number;
    target: string;
    gpu: string;
    gfx: string;
    vfs: string;
  };
  processes: Array<{
    usage: string;
    wakeups: number;
    category: string;
    description: string;
  }>;
  devices: Array<{
    usage: string;
    name: string;
    type: string;
  }>;
  cpuStates: {
    package: Record<string, number>;
    cores: Array<Record<string, number>>;
    cpus: Array<{
      id: number;
      states: Record<string, { percentage: number; duration?: string }>;
    }>;
  };
}

export function parsePowerTopHtml(htmlContent: string): PowerTopData {
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlContent, 'text/html');

  return {
    timestamp: extractTimestamp(doc),
    systemInfo: extractSystemInfo(doc),
    summary: extractSummary(doc),
    processes: extractProcesses(doc),
    devices: extractDevices(doc),
    cpuStates: extractCpuStates(doc)
  };
}

function extractTimestamp(doc: Document): string {
  const sysInfo = doc.querySelector('.sys_info');
  const versionRow = sysInfo?.querySelector('tr')?.textContent;
  return versionRow?.match(/ran at (.+)/)?.[1]?.trim() || new Date().toLocaleString();
}

function extractSystemInfo(doc: Document): PowerTopData['systemInfo'] {
  const rows = Array.from(doc.querySelectorAll('.sys_info tr'));
  return {
    version: extractTableValue(rows, 'PowerTOP Version'),
    kernel: extractTableValue(rows, 'Kernel Version'),
    system: extractTableValue(rows, 'System Name'),
    cpu: extractTableValue(rows, 'CPU Information'),
    os: extractTableValue(rows, 'OS Information')
  };
}

function extractSummary(doc: Document): PowerTopData['summary'] {
  const summaryList = Array.from(doc.querySelectorAll('li.summary_list'));
  const getValue = (label: string) => {
    const item = summaryList.find(li => li.textContent?.includes(label));
    return item?.textContent?.split(':')[1]?.trim() || '';
  };

  return {
    target: getValue('Target'),
    powerConsumption: 0, // Not directly available in summary
    cpuUsage: parseFloat(getValue('CPU').replace('%', '')) || 0,
    runtime: 0, // Not directly available in summary
    wakeups: parseFloat(getValue('System').replace('wakeup/s', '')) || 0,
    gpu: getValue('GPU'),
    gfx: getValue('GFX'),
    vfs: getValue('VFS')
  };
}

function extractProcesses(doc: Document): PowerTopData['processes'] {
  const table = doc.querySelector('#software table');
  if (!table) return [];

  return Array.from(table.querySelectorAll('tr'))
    .slice(1) // Skip header row
    .map(row => {
      const cells = Array.from(row.querySelectorAll('td'));
      return {
        usage: cells[0]?.textContent?.trim() || '',
        wakeups: parseFloat(cells[1]?.textContent?.trim() || '0'),
        category: cells[4]?.textContent?.trim() || '',
        description: cells[6]?.textContent?.trim() || ''
      };
    })
    .filter(process => process.description !== '');
}

function extractDevices(doc: Document): PowerTopData['devices'] {
  const table = doc.querySelector('#devinfo table');
  if (!table) return [];

  return Array.from(table.querySelectorAll('tr'))
    .slice(1) // Skip header row
    .map(row => {
      const cells = Array.from(row.querySelectorAll('td'));
      const usage = cells[0]?.textContent?.trim() || '';
      const name = cells[1]?.textContent?.trim() || '';
      
      return {
        usage,
        name,
        type: determineDeviceType(name)
      };
    })
    .filter(device => device.name !== '');
}

function extractCpuStates(doc: Document): PowerTopData['cpuStates'] {
  const packageStates: Record<string, number> = {};
  const coreStates: Array<Record<string, number>> = [];
  const cpuStates: Array<{
    id: number;
    states: Record<string, { percentage: number; duration?: string }>;
  }> = [];

  // Extract package states
  const packageTable = doc.querySelector('#cpuidle table');
  if (packageTable) {
    Array.from(packageTable.querySelectorAll('tr')).forEach(row => {
      const cells = Array.from(row.querySelectorAll('td'));
      if (cells.length === 2) {
        const state = cells[0]?.textContent?.trim() || '';
        const value = parseFloat(cells[1]?.textContent?.replace('%', '').trim() || '0');
        if (state && !isNaN(value)) {
          packageStates[state] = value;
        }
      }
    });
  }

  return {
    package: packageStates,
    cores: coreStates,
    cpus: cpuStates
  };
}

function extractTableValue(rows: Element[], label: string): string {
  const row = rows.find(row => row.textContent?.includes(label));
  return row?.querySelector('td')?.textContent?.trim() || '';
}

function determineDeviceType(name: string): string {
  if (name.includes('CPU')) return 'cpu';
  if (name.includes('GPU') || name.includes('Graphics')) return 'gpu';
  if (name.includes('USB')) return 'usb';
  if (name.includes('Network') || name.includes('nic:')) return 'network';
  if (name.includes('Audio')) return 'audio';
  if (name.includes('PCI')) return 'pci';
  return 'other';
}